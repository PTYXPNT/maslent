const ownermenu = (prefix) => { 
	return `
	
╭┈─────𝙵𝙸𝚃𝚄𝚁 𝙽𝚈𝙰 𝙺𝙰𝙺
╰─❁۪۪
╰─➤ *${prefix}block 62858xxxxx*
╰─➤ *${prefix}unblock 62858xxxxx*
╰─➤ *${prefix}promote @tagmember*
╰─➤ *${prefix}demote @tagadmin*
╰─➤ *${prefix}bc*
╰─➤ *${prefix}leave*
╰─➤  *${prefix}bc2*
╰─➤  *${prefix}leave*
╰─➤  *${prefix}clearall*
╰─➤  *${prefix}clone*
╰─➤  *${prefix}hidetag*
╰─➤  *${prefix}hidetag2*
╰─➤  *${prefix}setprefix*
╰─➤  *${prefix}unban*
╰─➤  *${prefix}ban*
╰─➤ *${prefix}runtime*
╰─➤ *${prefix}turnoff*
╰─➤  *${prefix}getses*
╭┈─────𝚝𝚑𝚊𝚗𝚡 𝚝𝚘 𝚖𝚊𝚜𝚕𝚎𝚗𝚝 𝚢𝚝
╰─❁۪۪`
}
exports.ownermenu = ownermenu